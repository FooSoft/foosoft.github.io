#!/usr/bin/perl


sub generate_report {
    my $count = shift;
    print("\tat least $count times...\n");
    system("./scripts/kanjitable.pl ./frequency/wikipedia $count ./lists/rtk1 ./lists/rtk13 ./lists/jouyou1981 ./lists/jouyou2009 ./lists/jinmeiyou > report$count.html");    
}

printf("Generating reports for characters appearing:\n");

&generate_report(10000);
&generate_report(1000);
&generate_report(100);
&generate_report(10);
&generate_report(1);

printf("Done!\n");
