#!/usr/bin/perl

use strict;
use warnings;
use Encode;
use File::Find;

my %frequency = ();

sub is_kanji {
    my $code = ord(shift);
    return $code >= 19968 && $code <= 40959;
}

sub process_content {
    my @chars = split(//, shift);
    foreach (@chars) {
        if (&is_kanji($_)) {
            $frequency{$_} = (exists($frequency{$_}) ? $frequency{$_} + 1 : 1);
        }
    }
}

sub process_file {
    /\.html$/ or return;
    my $fname = $_;
    print("Processing ", decode_utf8($fname), "...\n");
    open(my $file, "<", $fname) or die("Cannot open $fname for read!");
    my @lines = <$file>;        
    if (decode_utf8("@lines") =~ /<!-- start content -->([\s\S]+)<!-- end content -->/) {
        &process_content($1);
    }
    close($file);
}

sub output_results {
    my $fname = shift;
    print("Outputting results to $fname...\n");
    open(my $file, ">", $fname) or die("Cannot open $fname for write!");
    binmode $file, ":utf8";
    my @keys = reverse sort { $frequency{$a} <=> $frequency{$b} } keys(%frequency);
    foreach (@keys) {
        print $file "$_,$frequency{$_}\n";
    }
    close($file);
}

binmode STDOUT, ":utf8";
if ($#ARGV >= 0) {    
    find(\&process_file, @ARGV[1..$#ARGV]);
    &output_results($ARGV[0]);
}
else {
    print("Usage: kanjifreq.pl OUTPUT_FILE INPUT_DIRECTORY...\n");
}
