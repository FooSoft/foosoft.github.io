#!/usr/bin/perl

use strict;
use warnings;
use Encode;

binmode STDIN,  ":utf8";
binmode STDOUT, ":utf8";

sub is_kanji {
    my $code = ord(shift);
    return $code >= 19968 && $code <= 40959;
}

while (<STDIN>) {
    foreach (split(//)) {
        &is_kanji($_) && print();
    }
}
